package com.example.farmlink

data class CustomerModel(
    var cusId:String? =null,
    var cusName:String? =null,
    var cusEmail:String? =null,
    var cusUsername:String? =null,
    var cusPassword:String? =null
)