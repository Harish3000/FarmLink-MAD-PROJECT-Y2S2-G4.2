package com.example.farmlink

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CustomerSettings : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_customer_settings)
    }
}